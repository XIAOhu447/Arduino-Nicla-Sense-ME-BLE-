#include <ArduinoBLE.h>
// 1. 定义 BLE 服务和特性（消息传输的核心）
// 服务 UUID（自定义，也可使用标准 UUID，此处用常用自定义 UUID）
BLEService msgService("19b10000-e8f2-537e-4f6c-d104768a1214"); 
// 特性 UUID（绑定到服务，支持“读”和“通知”，最大存储20字节）
// BLERead：接收端可主动读取；BLENotify：接收端订阅后，发送端更新时会主动推送
BLECharacteristic msgChar("19b10001-e8f2-537e-4f6c-d104768a1214", 
                         BLERead | BLENotify, 20); 


// 要发送的消息（可自定义）
const char* sendMsg = "Hello from Arduino BLE!";
// 计时变量（避免用 delay() 阻塞 BLE 事件）
unsigned long lastSendTime = 0;
// 发送间隔（1000ms = 1秒）
const unsigned long sendInterval = 1000;//单位ms

void setup() 
{
  // 初始化串口
  Serial.begin(9600);
  while (!Serial); // 等待串口打开
  // 2. 初始化 BLE 并检查状态
  if (!BLE.begin()) 
  {
    Serial.println("初始化 BLE 失败！");
    while (1); // 失败则死循环报错
  }

  // 3. 配置 BLE 服务和特性（关键步骤：将特性绑定到服务，服务注册到 BLE）
  BLE.setLocalName("ArduinoBLE"); // 设备名（手机搜索时显示）
  BLE.setAdvertisedService(msgService); // 广播时关联服务（让接收端知道设备有此功能）
  msgService.addCharacteristic(msgChar); // 将特性添加到服务
  BLE.addService(msgService); // 将服务注册到 BLE 协议栈
  // 4. 初始写入消息（可选：让接收端连接后能立即读到初始值）
  msgChar.writeValue(sendMsg);
  // 5. 开始 BLE 广播（等待手机/其他设备连接）
  BLE.advertise();

  /****************************串口测试监控信息**********************/
  Serial.println("BLE 广播已启动，等待连接...");
  Serial.print("待发送消息：");
  Serial.println(sendMsg);
}
void ble_event(void) 
{
 BLEDevice central = BLE.central();// 获取连接的设备对象（若无连接则为空）
  
 if (central) // 若有设备连接（central = 手机/接收端）
  { 
    static bool isConnected = false; // 标记是否刚连接，避免重复打印
    if (!isConnected)
     {
      Serial.print("已连接设备：");
      Serial.println(central.address()); // 打印接收端蓝牙地址
      isConnected = true;
    }

    // 8. 每秒发送一次消息（用 millis() 避免阻塞 BLE 事件）
    if (ifmillis() - lastSendTime >= sendInterval) 
    {
      lastSendTime = millis();
      // 核心：写入消息到特性（发送数据）
      msgChar.writeValue(sendMsg);
       /****************************串口测试监控信息**********************/
      Serial.print("已发送：");
      Serial.println(sendMsg); // 串口打印发送内容，方便调试
    }
    // 9. 若连接断开，重置标记
    if (!central.connected()) 
    {
      // 若连接断开，重置标记并打印信息
      Serial.print("设备已断开：");
      Serial.println(central.address());
      isConnected = false;
      lastSendTime = 0; // 重置计时
    }
  } 
  else 
  {
    // 无设备连接时，每秒打印状态（可选）
    if (millis() - lastSendTime >= sendInterval) 
    {
      lastSendTime = millis();// 更新计时
       /****************************串口测试监控信息**********************/
      Serial.println("BLE测试中...（等待设备连接）");

    }
  }
}
void send_msg(const char* msg) //用于发送消息，如果添加到loop中，需要注意频率不要太高，否则会阻塞BLE事件处理
{
   BLEDevice central = BLE.central();// 获取连接的设备对象（若无连接则为空）
  if (central)
  {
  sendMsg = msg;
  msgChar.writeValue(sendMsg);
  }
  else if (!central.connected())
  {
    Serial.print("没有可用设备连接，无法发送消息！");
    Serial.println(central.address());
    
  }
}
void loop() 
{
  // 6. 处理 BLE 底层事件（必须保留，否则连接/通信会异常）
  BLE.poll();
  ble_event();

}
